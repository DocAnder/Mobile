package com.example.views;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

import com.example.views.databinding.ActivityMainBinding;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnLimpar.setOnClickListener(this);
        binding.btnExibir.setOnClickListener(this);

    }


    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btnLimpar){
            //Toast.makeText(this, "Limpar", Toast.LENGTH_SHORT).show();
            binding.edtNome.setText("");
            binding.edtEmail.setText("");
            binding.edtTelefone.setText("");
            binding.ckEsporte.setChecked(false);
            binding.ckGastro.setChecked(false);
            binding.ckMusica.setChecked(false);
            binding.ckCinema.setChecked(false);
            binding.radioGroup.clearCheck();
            binding.whatsapp.setChecked(false);
        }
        else if (view.getId() == R.id.btnExibir){
            //Toast.makeText(this, "Exibir", Toast.LENGTH_LONG).show();
            binding.txtNome.setText("Nome: " + binding.edtNome.getText());
            binding.txtEmail.setText("Email: " + binding.edtEmail.getText());
            binding.txtTelefone.setText("Tel: " + binding.edtTelefone.getText());
            binding.lblDados.setVisibility(View.VISIBLE);
            if (binding.whatsapp.isChecked()){
                binding.txtZapzap.setText("Notificações: " +
                        binding.whatsapp.getTextOn());
            }else{
                binding.txtZapzap.setText("Notificações " +
                        binding.whatsapp.getTextOff());
            }

            int idRadioSelecionado = binding.radioGroup.getCheckedRadioButtonId();
            if (idRadioSelecionado > 0){
                RadioButton radioButtonSelecionado = findViewById(idRadioSelecionado);
                binding.txtSexo.setText("Sexo: " +
                        radioButtonSelecionado.getText().toString());
            }

            String texto = "";
            if(binding.ckEsporte.isChecked()){
                texto = binding.ckEsporte.getText().toString();
            }
            if(binding.ckGastro.isChecked()){
                texto += ", " + binding.ckGastro.getText().toString();
            }
            if(binding.ckCinema.isChecked()){
                texto += ", " + binding.ckCinema.getText().toString();
            }
            if(binding.ckMusica.isChecked()){
                texto += ", " + binding.ckMusica.getText().toString();
            }
            binding.txtPreferencias.setText("Preferências: " + texto);
        }
    }



}

