package com.example.exercicio04;

import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;


import androidx.appcompat.app.AppCompatActivity;

import com.example.exercicio04.databinding.ActivityMainBinding;


public class MainActivity extends AppCompatActivity implements View.OnClickListener, SeekBar.OnSeekBarChangeListener {


    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.editText.setOnClickListener(this);
        binding.seekBarCor.setOnSeekBarChangeListener(this);


    }

    @Override
    public void onClick(View view) {

    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {

    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
}