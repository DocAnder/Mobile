package com.example.exercicio04;

import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.SeekBar;


import androidx.appcompat.app.AppCompatActivity;

import com.example.exercicio04.databinding.ActivityMainBinding;


public class MainActivity extends AppCompatActivity implements View.OnClickListener, SeekBar.OnSeekBarChangeListener, CompoundButton.OnCheckedChangeListener {


    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.butonTexto.setOnClickListener(this);
        binding.seekBarCor.setOnSeekBarChangeListener(this);
        binding.cbNegrito.setOnCheckedChangeListener(this);
        binding.cbItalico.setOnCheckedChangeListener(this);
        binding.rbAzul.setOnCheckedChangeListener(this);
        binding.rbVerde.setOnCheckedChangeListener(this);
        binding.rbVermelho.setOnCheckedChangeListener(this);



    }

    @Override
    public void onClick(View view) {
        String texto = String.valueOf(binding.editText.getText());
        binding.barraCor.setText(texto);
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
        binding.barraCor.setTextSize(i);
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }


    @Override
    public void onCheckedChanged(CompoundButton button, boolean b) {
        int estilo = Typeface.NORMAL;

        if (binding.cbNegrito.isChecked()){
            estilo += Typeface.BOLD;
        }else {
            estilo += Typeface.NORMAL;
        }

        if (binding.cbItalico.isChecked()){
            estilo += Typeface.ITALIC;
        }else {
            estilo += Typeface.NORMAL;
        }

        if (binding.cbMaiusculas.isChecked()){
            binding.barraCor.setAllCaps(true);
        }else {
            binding.barraCor.setAllCaps(false);
        }

        if (binding.rbVermelho.isChecked()){
            binding.barraCor.setTextColor(Color.RED);
        } else if(binding.rbVerde.isChecked()){
            binding.barraCor.setTextColor(Color.GREEN);
        }else if(binding.rbAzul.isChecked()){
            binding.barraCor.setTextColor(Color.BLUE);
        } else {
            binding.barraCor.setTextColor(Color.BLACK);
        }


        binding.barraCor.setTypeface(null, estilo);

    }


}